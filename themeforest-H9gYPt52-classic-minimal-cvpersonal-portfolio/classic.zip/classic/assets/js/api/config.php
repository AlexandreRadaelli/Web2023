<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'huQ7ZbwiMmdNL7CCvk2F16Mj6');
    define('CONSUMER_SECRET', '99wKPnDcipoZpC9JKKCTx7yZsa4aqRl6O2QCScrhgfN01GbZ3t');

    // User Access Token
    define('ACCESS_TOKEN', '754768028-sWXTBw9y0f1064aUMKAfO1gg23ymG20L5WfrPZ5g');
    define('ACCESS_SECRET', 'EF4kJVqUrGICSxk96XmSkjmO5dVm7ZqOzXlWLorVPFEJB');
    
    // Cache Settings
    define('CACHE_ENABLED', false);
    define('CACHE_LIFETIME', 3600); // in seconds
    define('HASH_SALT', md5(dirname(__FILE__)));